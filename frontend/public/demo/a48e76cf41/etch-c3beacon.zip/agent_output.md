## Reasoning

**Requirements.** Battery-powered motion-wake beacon: LiPo + USB-C charging, 3.3 V LDO, one button, one status LED, MPU-6050 for wake-on-motion, small footprint.

**MCU.** ESP32-C3-WROOM-02: native USB-serial-JTAG on IO18/IO19, so USB-C serves both charging and programming with no CH340C — saves an IC and quiescent current. EN gets 10k pull-up + 100 nF, IO9 gets 10k pull-up and the tactile button (SW1) which doubles as BOOT and the user button (standard C3 dev-board practice; IO9 is a normal input after boot). SW2 on EN is the reset button. IO8 gets a 10k pull-up (must be high at boot).

**Power tree.** VBUS 5 V → USBLC6 TVS on VBUS/D+/D- → TP4056 (PROG 2k ≈ 580 mA charge current, TEMP tied to GND to disable NTC, CE to VCC, CHRG open-drain LED via 1k). BAT node (3.0–4.2 V) → AP2112K-3.3 (600 mA, ~55 µA Iq, ~250 mV dropout — enough headroom for the C3's ~350 mA Wi-Fi/BLE bursts, unlike MCP1700's 250 mA). 1 µF in, 1 µF + 10 µF + 100 nF on 3V3. Power LED (1k, green) hangs on the 5 V rail so it only draws ~3 mA while on USB, not from the battery.

**I/O map.** IO5 = SDA, IO6 = SCL with 4.7k pull-ups to 3V3. MPU-6050 INT → IO3 (RTC-capable GPIO 0–5 on the C3, so it can wake deep sleep via motion-detect interrupt). IO10 → status LED via 1k (~1.5 mA). IO9 = button.

**MPU-6050.** VDD and VLOGIC on 3V3 with 100 nF each, REGOUT 100 nF, CPOUT 2.2 nF, AD0/CLKIN/FSYNC to GND (address 0x68).

**Trade-offs.** No load-sharing path: the LDO runs from the BAT node, so the TP4056 sees system load during charge and may not terminate cleanly — acceptable for a low-duty beacon (deep sleep ≈ 60–80 µA total). No power switch to keep the board small; add one on the BAT net if needed. USB-C CC pull-downs (2 × 5.1k) request default 5 V.

**Total parts: 34**, board ≈ 46 × 34 mm.

```json
{
  "name": "C3Beacon",
  "tagline": "LiPo-powered ESP32-C3 motion-wake BLE beacon",
  "summary": "A small battery-powered beacon built around an ESP32-C3 Wi-Fi/Bluetooth module. It charges a LiPo battery over USB-C, sleeps to save power, and an on-board accelerometer wakes it up when it is moved. One button and one LED provide simple user interaction.",
  "board": {"width": 46, "height": 34, "mounting_holes": true},
  "power": {
    "input": "USB-C 5 V (charging) / 1S LiPo 3.7 V",
    "rails": [
      {"net": "5V", "voltage": 5.0, "current_ma": 800},
      {"net": "BAT", "voltage": 3.7, "current_ma": 600},
      {"net": "3V3", "voltage": 3.3, "current_ma": 500}
    ]
  },
  "components": [
    {"ref": "J1", "part": "usb-c-16p", "value": "", "purpose": "USB-C for charging and native USB programming"},
    {"ref": "R1", "part": "r-0603", "value": "5.1k", "purpose": "CC1 pull-down, 5 V sink advertisement"},
    {"ref": "R2", "part": "r-0603", "value": "5.1k", "purpose": "CC2 pull-down, 5 V sink advertisement"},
    {"ref": "D1", "part": "tvs-usblc6", "value": "", "purpose": "ESD protection on VBUS, D+, D-"},
    {"ref": "U1", "part": "tp4056", "value": "", "purpose": "LiPo charger, 580 mA"},
    {"ref": "R3", "part": "r-0603", "value": "2k", "purpose": "PROG resistor sets 580 mA charge current"},
    {"ref": "C1", "part": "c-0805", "value": "10uF", "purpose": "5 V input bulk cap for charger"},
    {"ref": "C2", "part": "c-0805", "value": "10uF", "purpose": "Battery node bulk cap"},
    {"ref": "D2", "part": "led-0603", "value": "red", "purpose": "Charging indicator"},
    {"ref": "R4", "part": "r-0603", "value": "1k", "purpose": "Charge LED series resistor"},
    {"ref": "J2", "part": "jst-ph-2", "value": "", "purpose": "1S LiPo battery connector"},
    {"ref": "U2", "part": "ap2112k-3.3", "value": "", "purpose": "3.3 V LDO, 600 mA, low Iq"},
    {"ref": "C3", "part": "c-0603", "value": "1uF", "purpose": "LDO input cap"},
    {"ref": "C4", "part": "c-0603", "value": "1uF", "purpose": "LDO output cap"},
    {"ref": "U3", "part": "esp32-c3-wroom-02", "value": "", "purpose": "ESP32-C3 MCU with BLE/Wi-Fi, native USB"},
    {"ref": "C5", "part": "c-0805", "value": "10uF", "purpose": "3V3 bulk cap for RF bursts"},
    {"ref": "C6", "part": "c-0603", "value": "100nF", "purpose": "ESP32-C3 3V3 decoupling"},
    {"ref": "R5", "part": "r-0603", "value": "10k", "purpose": "EN pull-up"},
    {"ref": "C7", "part": "c-0603", "value": "100nF", "purpose": "EN reset delay cap"},
    {"ref": "SW1", "part": "sw-tact-smd", "value": "", "purpose": "User/BOOT button on IO9"},
    {"ref": "R6", "part": "r-0603", "value": "10k", "purpose": "IO9 boot/button pull-up"},
    {"ref": "SW2", "part": "sw-tact-smd", "value": "", "purpose": "Reset button on EN"},
    {"ref": "R11", "part": "r-0603", "value": "10k", "purpose": "IO8 pull-up, required high at boot"},
    {"ref": "D3", "part": "led-0603", "value": "blue", "purpose": "Status LED on IO10"},
    {"ref": "R7", "part": "r-0603", "value": "1k", "purpose": "Status LED series resistor"},
    {"ref": "D4", "part": "led-0603", "value": "green", "purpose": "Power LED, lit when USB connected"},
    {"ref": "R8", "part": "r-0603", "value": "1k", "purpose": "Power LED series resistor"},
    {"ref": "U4", "part": "mpu6050", "value": "", "purpose": "Accelerometer/gyro, motion-wake interrupt"},
    {"ref": "C9", "part": "c-0603", "value": "100nF", "purpose": "MPU-6050 VDD decoupling"},
    {"ref": "C10", "part": "c-0603", "value": "100nF", "purpose": "MPU-6050 VLOGIC decoupling"},
    {"ref": "C11", "part": "c-0603", "value": "100nF", "purpose": "MPU-6050 REGOUT cap"},
    {"ref": "C12", "part": "c-0603", "value": "2.2nF", "purpose": "MPU-6050 CPOUT charge-pump cap"},
    {"ref": "R9", "part": "r-0603", "value": "4.7k", "purpose": "I2C SDA pull-up"},
    {"ref": "R10", "part": "r-0603", "value": "4.7k", "purpose": "I2C SCL pull-up"}
  ],
  "nets": [
    {"name": "GND", "cls": "gnd", "pins": ["J1.A1B12", "J1.B1A12", "J1.S1", "J1.S2", "J1.S3", "J1.S4", "D1.2", "R1.2", "R2.2", "U1.1", "U1.3", "R3.2", "C1.2", "C2.2", "J2.2", "U2.2", "C3.2", "C4.2", "U3.9", "U3.19", "C5.2", "C6.2", "C7.2", "SW1.3", "SW2.3", "D3.1", "D4.1", "U4.1", "U4.9", "U4.11", "U4.18", "C9.2", "C10.2", "C11.2", "C12.2"]},
    {"name": "5V", "cls": "power", "pins": ["J1.A4B9", "J1.B4A9", "D1.5", "U1.4", "U1.8", "C1.1", "R4.1", "R8.1"]},
    {"name": "BAT", "cls": "power", "pins": ["U1.5", "C2.1", "J2.1", "U2.1", "U2.3", "C3.1"]},
    {"name": "3V3", "cls": "power", "pins": ["U2.5", "C4.1", "U3.1", "C5.1", "C6.1", "R5.1", "R6.1", "R11.1", "R9.1", "R10.1", "U4.13", "U4.8", "C9.1", "C10.1"]},
    {"name": "USB_DP", "cls": "highspeed", "pins": ["J1.A6", "J1.B6", "D1.1", "D1.6", "U3.14"]},
    {"name": "USB_DM", "cls": "highspeed", "pins": ["J1.A7", "J1.B7", "D1.3", "D1.4", "U3.13"]},
    {"name": "CC1", "cls": "signal", "pins": ["J1.A5", "R1.1"]},
    {"name": "CC2", "cls": "signal", "pins": ["J1.B5", "R2.1"]},
    {"name": "PROG", "cls": "signal", "pins": ["U1.2", "R3.1"]},
    {"name": "CHRG_LED", "cls": "signal", "pins": ["R4.2", "D2.2"]},
    {"name": "CHRG_N", "cls": "signal", "pins": ["U1.7", "D2.1"]},
    {"name": "PWR_LED", "cls": "signal", "pins": ["R8.2", "D4.2"]},
    {"name": "EN", "cls": "signal", "pins": ["U3.2", "R5.2", "C7.1", "SW2.1"]},
    {"name": "IO9_BOOT", "cls": "signal", "pins": ["U3.8", "R6.2", "SW1.1"]},
    {"name": "IO8_PU", "cls": "signal", "pins": ["U3.7", "R11.2"]},
    {"name": "LED_STAT", "cls": "signal", "pins": ["U3.10", "R7.1"]},
    {"name": "LED_STAT_A", "cls": "signal", "pins": ["R7.2", "D3.2"]},
    {"name": "SDA", "cls": "signal", "pins": ["U3.4", "R9.2", "U4.24"]},
    {"name": "SCL", "cls": "signal", "pins": ["U3.5", "R10.2", "U4.23"]},
    {"name": "MPU_INT", "cls": "signal", "pins": ["U3.15", "U4.12"]},
    {"name": "MPU_REGOUT", "cls": "analog", "pins": ["U4.10", "C11.1"]},
    {"name": "MPU_CPOUT", "cls": "analog", "pins": ["U4.20", "C12.1"]}
  ],
  "notes": [
    "Programming/flashing via native USB-serial-JTAG on IO18/IO19; no CH340C needed. Hold SW1 (IO9) while pressing SW2 (reset) to force download mode.",
    "SW1 doubles as user button after boot (IO9 with 10k pull-up, active-low).",
    "MPU-6050 INT on IO3 (RTC GPIO) enables deep-sleep wake on motion; configure motion-detect threshold and use esp_deep_sleep_enable_gpio_wakeup in firmware.",
    "LDO input is the BAT node (no load-sharing path). Charger termination may be delayed while the ESP32 is active; acceptable for a low-duty beacon. Keep charge current 580 mA (R3=2k) suitable for >=600 mAh cells; use 5k for ~230 mA on small cells.",
    "Power LED D4 is on 5V so it only draws current when USB is connected; deep-sleep battery draw dominated by AP2112K Iq (~55 uA) + ESP32-C3 (~5 uA) + MPU-6050 cycle mode (~10 uA).",
    "TP4056 TEMP tied to GND disables NTC monitoring; STDBY left open. Add 10k NTC path if cell has thermistor.",
    "No battery power switch included to keep board small; insert sw-slide in series with BAT to LDO VIN if required.",
    "Keep ESP32-C3 antenna overhanging/at board edge; keep MPU-6050 away from the LDO and USB connector for mechanical stability.",
    "Verify 3V3 bulk capacitance (10uF + 1uF + 100nF) is sufficient for BLE TX bursts; add another 10uF near U3 if brownouts occur."
  ],
  "estimated_cost_usd": 7.2
}
```